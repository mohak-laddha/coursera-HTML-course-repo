

# Module 02 Assignment

# Click on the [Solution](https://blrajkumar.github.io/Coursera_HTML_CSS_JS/mod2_solution/index.html) to see the output HTML page!
